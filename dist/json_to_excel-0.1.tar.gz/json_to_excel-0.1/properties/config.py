import os
import  inspect

properties_folder = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'properties')
excel_file = os.path.join(properties_folder, 'excel_database.xlsx')
